import React from "react";
import { Progress } from "./ui/progress";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";

interface SkillCategory {
  name: string;
  skills: {
    name: string;
    level: number;
  }[];
}

const SkillsSection = ({
  categories = defaultCategories,
}: {
  categories?: SkillCategory[];
}) => {
  return (
    <section id="skills" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-2">Technical Skills</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            My technical expertise spans across various programming languages,
            frameworks, and tools.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {categories.map((category, index) => (
            <Card
              key={index}
              className="shadow-md hover:shadow-lg transition-shadow duration-300"
            >
              <CardContent className="pt-6">
                <h3 className="text-xl font-semibold mb-4 text-center">
                  {category.name}
                </h3>
                <div className="space-y-4">
                  {category.skills.map((skill, skillIndex) => (
                    <div key={skillIndex} className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="font-medium">{skill.name}</span>
                        <span className="text-sm text-gray-500">
                          {skill.level}%
                        </span>
                      </div>
                      <Progress value={skill.level} className="h-2" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-16">
          <h3 className="text-2xl font-bold mb-6 text-center">
            Additional Skills & Concepts
          </h3>
          <div className="flex flex-wrap justify-center gap-3">
            {additionalSkills.map((skill, index) => (
              <Badge
                key={index}
                variant="outline"
                className="px-4 py-2 text-sm bg-gray-50 hover:bg-gray-100"
              >
                {skill}
              </Badge>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

const defaultCategories: SkillCategory[] = [
  {
    name: "Languages",
    skills: [
      { name: "Java", level: 90 },
      { name: "SQL", level: 85 },
      { name: "HTML", level: 80 },
      { name: "CSS", level: 75 },
    ],
  },
  {
    name: "Frameworks",
    skills: [
      { name: "Spring Boot", level: 85 },
      { name: "Hibernate", level: 80 },
      { name: "JPA", level: 80 },
      { name: "JDBC", level: 75 },
    ],
  },
  {
    name: "Database",
    skills: [
      { name: "MySQL", level: 85 },
      { name: "Relational DB Design", level: 80 },
      { name: "SQL Queries", level: 85 },
    ],
  },
  {
    name: "Web/API",
    skills: [
      { name: "REST APIs", level: 85 },
      { name: "MVC Architecture", level: 80 },
      { name: "JSON", level: 85 },
    ],
  },
  {
    name: "Tools",
    skills: [
      { name: "Git", level: 80 },
      { name: "Eclipse", level: 85 },
      { name: "IntelliJ", level: 80 },
      { name: "VS Code", level: 75 },
      { name: "Postman", level: 85 },
    ],
  },
];

const additionalSkills = [
  "OOP",
  "SDLC",
  "CRUD",
  "Exception Handling",
  "Agile",
  "DBMS",
  "Multithreading",
  "JSP",
  "Servlets",
  "AWS Cloud",
  "Project Management",
];

export default SkillsSection;
