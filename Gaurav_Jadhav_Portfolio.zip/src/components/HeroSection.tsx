import React from "react";
import { Button } from "./ui/button";
import { ArrowDownToLine, ArrowRight } from "lucide-react";

interface HeroSectionProps {
  name?: string;
  title?: string;
  tagline?: string;
  resumeUrl?: string;
}

const HeroSection = ({
  name = "Gaurav Subhash Jadhav",
  title = "Java Developer",
  tagline = "Building robust backend solutions with Java, Spring Boot, and Hibernate",
  resumeUrl = "https://drive.google.com/file/d/1iiqUJiNQBnnremxyJsPvlGWU6xwCp2Hd/view?usp=sharing",
}: HeroSectionProps) => {
  return (
    <section className="bg-white min-h-[700px] flex items-center justify-center w-full py-16 px-4 md:px-8 lg:px-16">
      <div className="max-w-7xl w-full flex flex-col-reverse md:flex-row items-center justify-between gap-10">
        {/* Left content */}
        <div className="w-full md:w-1/2 space-y-6 text-center md:text-left">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-800">
            Hi, I'm <span className="text-blue-600">{name}</span>
          </h1>
          <h2 className="text-2xl md:text-3xl font-medium text-gray-700">
            {title}
          </h2>
          <p className="text-lg text-gray-600 max-w-lg">{tagline}</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start pt-4">
            <Button
              className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-md flex items-center gap-2"
              onClick={() => window.open(resumeUrl, "_blank")}
            >
              <ArrowDownToLine size={18} />
              Download Resume
            </Button>
            <Button
              variant="outline"
              className="border-blue-600 text-blue-600 hover:bg-blue-50 px-6 py-2 rounded-md flex items-center gap-2"
            >
              View Projects
              <ArrowRight size={18} />
            </Button>
          </div>
        </div>

        {/* Right content - Profile Image */}
        <div className="w-full md:w-1/2 flex justify-center md:justify-end">
          <div className="relative">
            <div className="absolute inset-0 bg-blue-600 rounded-full blur-md opacity-20 transform scale-95"></div>
            <div className="h-64 w-64 md:h-80 md:w-80 rounded-full overflow-hidden border-4 border-white shadow-xl relative z-10">
              <img
                src="/images/Gaurav photo.jpg"
                alt="Gaurav Jadhav"
                className="w-full h-full object-cover"
                onError={(e) => {
                  e.currentTarget.src =
                    "https://api.dicebear.com/7.x/avataaars/svg?seed=gaurav";
                }}
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
