import React, { useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { ExternalLink, Github, Code } from "lucide-react";

interface Project {
  id: string;
  title: string;
  description: string;
  longDescription?: string;
  technologies: string[];
  image?: string;
  links?: {
    demo?: string;
    github?: string;
  };
  category: string;
}

const ProjectsSection = () => {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [filter, setFilter] = useState<string>("all");

  const projects: Project[] = [
    {
      id: "1",
      title: "Hospital Management System",
      description:
        "A comprehensive portal for hospital administration with secure authentication.",
      longDescription:
        "Developed a hospital portal supporting admin login and secure authentication. Implemented modules for patient registration, doctor assignment, appointment booking, and billing. Created full CRUD operations using RESTful APIs and followed MVC architecture with Hibernate ORM for backend operations.",
      technologies: [
        "Java",
        "Spring Boot",
        "Hibernate",
        "MySQL",
        "RESTful API",
        "MVC",
      ],
      image:
        "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=800&q=80",
      links: {
        github: "https://github.com/gauravjadhav/hospital-management",
        demo: "https://hospital-management-demo.vercel.app",
      },
      category: "web",
    },
    {
      id: "2",
      title: "Business Management System",
      description:
        "Role-based dashboards for business owners and customers with product management.",
      longDescription:
        "Designed role-based dashboards for business owners and customers. Implemented modules for product management, order tracking, and payment records. Handled relational data with Hibernate JPA and maintained consistent transactions.",
      technologies: ["Java", "Spring Boot", "Hibernate", "MySQL", "JPA"],
      image:
        "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&q=80",
      category: "web",
    },
  ];

  const filteredProjects =
    filter === "all"
      ? projects
      : projects.filter((project) => project.category === filter);

  return (
    <section id="projects" className="py-16 px-4 md:px-8 bg-white">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-2 text-gray-800">Projects</h2>
          <div className="w-20 h-1 bg-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Explore my recent development projects showcasing my technical
            skills and problem-solving abilities.
          </p>
        </div>

        <Tabs defaultValue="all" className="mb-8">
          <div className="flex justify-center">
            <TabsList>
              <TabsTrigger value="all" onClick={() => setFilter("all")}>
                All
              </TabsTrigger>
              <TabsTrigger value="web" onClick={() => setFilter("web")}>
                Web Apps
              </TabsTrigger>
              <TabsTrigger value="mobile" onClick={() => setFilter("mobile")}>
                Mobile
              </TabsTrigger>
              <TabsTrigger value="other" onClick={() => setFilter("other")}>
                Other
              </TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="all" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8">
              {filteredProjects.map((project) => (
                <ProjectCard
                  key={project.id}
                  project={project}
                  onSelect={() => setSelectedProject(project)}
                />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="web" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8">
              {filteredProjects.map((project) => (
                <ProjectCard
                  key={project.id}
                  project={project}
                  onSelect={() => setSelectedProject(project)}
                />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="mobile" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8">
              {filteredProjects.map((project) => (
                <ProjectCard
                  key={project.id}
                  project={project}
                  onSelect={() => setSelectedProject(project)}
                />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="other" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8">
              {filteredProjects.map((project) => (
                <ProjectCard
                  key={project.id}
                  project={project}
                  onSelect={() => setSelectedProject(project)}
                />
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {selectedProject && (
        <ProjectDialog
          project={selectedProject}
          onClose={() => setSelectedProject(null)}
          isOpen={!!selectedProject}
        />
      )}
    </section>
  );
};

interface ProjectCardProps {
  project: Project;
  onSelect: () => void;
}

const ProjectCard = ({ project, onSelect }: ProjectCardProps) => {
  return (
    <Card className="overflow-hidden transition-all duration-300 hover:shadow-lg bg-white border border-gray-200">
      {project.image && (
        <div className="h-48 overflow-hidden">
          <img
            src={project.image}
            alt={project.title}
            className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
            onError={(e) => {
              const target = e.target as HTMLImageElement;
              target.src =
                "https://images.unsplash.com/photo-1551601651-2a8555f1a136?w=800&q=80";
            }}
          />
        </div>
      )}
      <CardHeader>
        <CardTitle>{project.title}</CardTitle>
        <CardDescription>{project.description}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex flex-wrap gap-2 mb-4">
          {project.technologies.slice(0, 4).map((tech, index) => (
            <Badge
              key={index}
              variant="secondary"
              className="bg-blue-100 text-blue-800 hover:bg-blue-200"
            >
              {tech}
            </Badge>
          ))}
          {project.technologies.length > 4 && (
            <Badge variant="outline">
              +{project.technologies.length - 4} more
            </Badge>
          )}
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button variant="outline" onClick={onSelect}>
          View Details
        </Button>
      </CardFooter>
    </Card>
  );
};

interface ProjectDialogProps {
  project: Project;
  onClose: () => void;
  isOpen: boolean;
}

const ProjectDialog = ({
  project,
  onClose,
  isOpen = true,
}: ProjectDialogProps) => {
  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-3xl">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold">
            {project.title}
          </DialogTitle>
          <DialogDescription className="text-base text-gray-600">
            {project.description}
          </DialogDescription>
        </DialogHeader>

        {project.image && (
          <div className="rounded-md overflow-hidden my-4">
            <img
              src={project.image}
              alt={project.title}
              className="w-full h-auto object-cover"
              onError={(e) => {
                const target = e.target as HTMLImageElement;
                target.src =
                  "https://images.unsplash.com/photo-1551601651-2a8555f1a136?w=800&q=80";
              }}
            />
          </div>
        )}

        <div className="space-y-4">
          <div>
            <h4 className="font-semibold text-lg mb-2">Project Overview</h4>
            <p className="text-gray-700">
              {project.longDescription || project.description}
            </p>
          </div>

          <div>
            <h4 className="font-semibold text-lg mb-2">Technologies Used</h4>
            <div className="flex flex-wrap gap-2">
              {project.technologies.map((tech, index) => (
                <Badge key={index} className="bg-blue-100 text-blue-800">
                  {tech}
                </Badge>
              ))}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ProjectsSection;
